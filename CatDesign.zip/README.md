
  # Cat Shelter Website Design

  This is a code bundle for Cat Shelter Website Design. The original project is available at https://www.figma.com/design/jlueCoTKZD2bABMGaSYM4f/Cat-Shelter-Website-Design.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  